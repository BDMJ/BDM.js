const LavalinkConnection = require("../Lavalink/index.js");

module.exports = LavalinkConnection;

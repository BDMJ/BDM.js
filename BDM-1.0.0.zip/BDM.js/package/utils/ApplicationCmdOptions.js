module.exports = {
id:"id of the slash cmd;.id",
name:"name of the slash cmd;.name",
description:"description of the slash cmd;.description",
version: "version of slash cmd;.version",
options:"options of slash cmd;.options",
guildID:"guildID of the slash cmd (returns null for global);.guildID",
applicationID:"returns Application ID",
defaultPermission : "returns default permission of the slash cmd;.defaultPermission",
timestamp:"returns timestamp of the creation of slash cmd (in ms);.timestamp",
createdAt:"returns the date of creation of slash cmd;.createdAt"
}

module.exports = {
  "faq1": "How can I become staff for DBD.JS\nTo become staff, you need a minimum of - 1k messages, in support channels\nBe Active\nAct professional, in Support Channels\nHave some knowledge of DBD.JS",
  "faq2": "To use Callbacks such onJoined. You must enable intents. It recommend both.",
  "faq3": "Error 429 with Music.\nThis error only occurs when your Server or Node has been blacklisted from Youtube API. (Ratelimited)\nOnly way to fix is, by waiting 1-2 weeks. This can be longer!",
  "faq4": "Why is it only \`Database Connected!\` But no Ready on Client?\nThis is because of your Host.\nYour server, may be slow and taking a while to start the Bot.",
  "faq5": "How can I get the \`@Giveaway Sponsor\`\nIn order to get the role, you must have one of these requirements.\nHost a giveaway with something worth $5. Example Nitro Classic",
  "faq6": "undefined",
  "faq7": "undefined",
  "faq8": "undefined",
  "faq9": "undefined",
  "faq10": "undefined",
  "faq11": "undefined",
  "faq12": "undefined",
  "faq13": "undefined",
  "faq14": "undefined"
}
module.exports = {
  title: "Current Song title",
  description: "Description of Current Song",
  duration: "Duration of Current Song (187 Seconds 03:07)",
  duration_left: "Duration of Current Song Left (150 Seconds 02:30)",
	current_duration: "Duration of The Current Song Playing (173 02:53)",
  userID: "Return userID",
  url: "Current Song URL",
  thumbnail: "Thumbnail of Current Song",
  publisher: "Publisher",
  publisher_url: "Publisher URL"
}
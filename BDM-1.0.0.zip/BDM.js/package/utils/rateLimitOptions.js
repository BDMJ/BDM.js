module.exports = {
  timeout: "Time before this session rate limit is restarted;.timeout",
  limit: "Amount of times you can request this endpoint before failing;.limit",
  method: "Method used to this endpoint;.method",
  path: "The path to the api endpoint that triggered the rate limit;.path",
  route: "The route that triggered this event;.route",
};

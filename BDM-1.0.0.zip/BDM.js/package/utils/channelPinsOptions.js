module.exports = {
  id: "The ID of the channel where the pins were updated;.id",
  name: "The name of the channel where the pins were updated;.name.deleteBrackets()",
  type: "The type of the channel where the pins were updated;.type",
  guild: "The guild's name of the channel where the pins were updated;.guild.name.deleteBrackets()",
  guildid: "The guild's ID of the channel where the pins were updated;.guild.id",
};

module.exports = {
command: "command that threw the error;.command",
function: "function that threw the error;.function",
error: "Error message that was thrown by the function;.error"
}

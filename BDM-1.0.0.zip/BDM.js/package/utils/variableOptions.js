module.exports = {
variable:"returns the main variable",
key:"returns the key used in db",
value:"returns the value of Variable",
for:"returns the id of the thing for which data was stored",
guild:"guild id for id returned by for",
type:"type of Variable",
timestamp:"timestamp of changes in the variable"
}

module.exports = {
	inviter: "The creator of the invite code the user use to join the server;.inviter.id",
  code: "The invite code the user use to join the server;.inviter.code",
	real: "The real invite that the user have;.real",
	fake: "The fake invite that the user have;.fake"
}
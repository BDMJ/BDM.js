module.exports = embedOrEmbeds => {
    return require("util").inspect(embedOrEmbeds)
}